from payments.views import app
